# Panel de gestión — React

Panel interno para admin y librarian: inicio de sesión, catálogo, búsqueda, alta/edición/baja lógica de libros, portadas, socios, préstamos, devoluciones, vencidos y reporte de títulos más prestados.

## Ejecutar

Recomendado: iniciar con el Compose de [`../infra/README.md`](../infra/README.md). Para desarrollo independiente:

```bash
npm ci
VITE_API_BASE_URL=http://localhost:8000/api/v1 npm run dev
```

El token se guarda en `localStorage` y se envía como `Authorization: Bearer`. El origen permitido en CORS se configura en la API. La portada se descarga con el token y se muestra desde un object URL local.
