import { useEffect, useState } from 'react';
import { BookOpen, Users, ClipboardList, AlertTriangle, BarChart3, LogOut, Search, Plus, RotateCcw, Library, Menu, X, Pencil, Trash2, ImagePlus } from 'lucide-react';

const API = (import.meta.env.VITE_API_BASE_URL || 'http://localhost:8000/api/v1').replace(/\/$/, '');
const nav = [
  ['books', 'Catálogo', BookOpen], ['members', 'Socios', Users], ['loans', 'Préstamos', ClipboardList],
  ['overdue', 'Vencidos', AlertTriangle], ['report', 'Reporte', BarChart3],
];

function useApi(token) {
  return async (path, options = {}) => {
    const headers = new Headers(options.headers || {});
    if (!(options.body instanceof FormData)) headers.set('Content-Type', 'application/json');
    if (token) headers.set('Authorization', `Bearer ${token}`);
    const response = await fetch(`${API}${path}`, { ...options, headers });
    if (response.status === 204) return null;
    const type = response.headers.get('content-type') || '';
    const body = type.includes('application/json') ? await response.json() : await response.blob();
    if (!response.ok) throw new Error(body.message || 'No fue posible completar la solicitud.');
    return body;
  };
}

export default function App() {
  const [token, setToken] = useState(localStorage.getItem('ml_token') || '');
  const [role, setRole] = useState(localStorage.getItem('ml_role') || '');
  const [user, setUser] = useState(localStorage.getItem('ml_user') || '');
  const [section, setSection] = useState('books');
  const [mobileOpen, setMobileOpen] = useState(false);
  const [notice, setNotice] = useState('');
  const [error, setError] = useState('');
  const api = useApi(token);

  function loggedIn(result, username) {
    localStorage.setItem('ml_token', result.access_token);
    localStorage.setItem('ml_role', result.role);
    localStorage.setItem('ml_user', username);
    setToken(result.access_token); setRole(result.role); setUser(username); setError('');
  }
  function logout() {
    ['ml_token', 'ml_role', 'ml_user'].forEach(k => localStorage.removeItem(k));
    setToken(''); setRole(''); setUser('');
  }
  function flash(message) { setNotice(message); setError(''); window.setTimeout(() => setNotice(''), 3500); }

  if (!token) return <Login api={api} onLogin={loggedIn} />;
  return <div className="layout">
    <aside className={`sidebar ${mobileOpen ? 'open' : ''}`}>
      <div className="brand"><span className="brand-icon"><Library size={21} /></span><span>Manager<span className="brand-light">Library</span></span><button className="icon-btn mobile-close" onClick={() => setMobileOpen(false)} aria-label="Cerrar menú"><X /></button></div>
      <div className="side-caption">GESTIÓN</div>
      <nav aria-label="Navegación principal">{nav.map(([id, label, Icon]) => <button key={id} className={`nav-item ${section === id ? 'active' : ''}`} onClick={() => { setSection(id); setMobileOpen(false); }}><Icon size={18} /><span>{label}</span>{id === 'overdue' && section === id && <span className="nav-dot" />}</button>)}</nav>
      {role === 'admin' && <div className="admin-note"><span className="side-caption">ADMINISTRACIÓN</span><button className={`nav-item ${section === 'users' ? 'active' : ''}`} onClick={() => { setSection('users'); setMobileOpen(false); }}><Users size={18} /><span>Usuarios</span></button></div>}
      <div className="sidebar-bottom"><div className="avatar">{user.slice(0, 1).toUpperCase()}</div><div className="user-meta"><strong>{user}</strong><span>{role === 'admin' ? 'Administrador' : 'Bibliotecario'}</span></div><button className="icon-btn logout" aria-label="Cerrar sesión" title="Cerrar sesión" onClick={logout}><LogOut size={17} /></button></div>
    </aside>
    <main className="main-area">
      <header className="topbar"><button className="icon-btn mobile-menu" onClick={() => setMobileOpen(true)} aria-label="Abrir menú"><Menu /></button><div className="breadcrumb">Manager Library <span>/</span> <strong>{nav.find(n => n[0] === section)?.[1] || 'Usuarios'}</strong></div><div className="topbar-right"><span className="status-dot" /> Acceso privado</div></header>
      <div className="page-content">
        {notice && <div className="toast success" role="status">{notice}</div>}{error && <div className="toast danger" role="alert">{error}</div>}
        {section === 'books' && <Books api={api} role={role} onError={setError} onDone={flash} />}
        {section === 'members' && <Members api={api} onError={setError} onDone={flash} />}
        {section === 'loans' && <Loans api={api} onError={setError} onDone={flash} />}
        {section === 'overdue' && <Overdue api={api} onError={setError} onDone={flash} />}
        {section === 'report' && <Report api={api} role={role} onError={setError} />}
        {section === 'users' && role === 'admin' && <UsersPanel api={api} onError={setError} onDone={flash} />}
      </div>
    </main>
  </div>;
}

function Login({ api, onLogin }) {
  const [username, setUsername] = useState(''); const [password, setPassword] = useState(''); const [error, setError] = useState(''); const [busy, setBusy] = useState(false);
  async function submit(e) { e.preventDefault(); setBusy(true); setError(''); try { const result = await api('/auth/login', { method: 'POST', body: JSON.stringify({ username, password }) }); onLogin(result, username.trim().toLowerCase()); } catch (e) { setError(e.message); } finally { setBusy(false); } }
  return <div className="login-page"><div className="login-art"><div className="art-mark"><Library size={28} /> MANAGER LIBRARY</div><div className="art-copy"><span className="eyebrow">UN ESPACIO PARA CADA HISTORIA</span><h1>Una biblioteca<br />bien organizada<br /><em>abre más puertas.</em></h1><p>Administra el catálogo, los socios y los préstamos desde un solo lugar.</p></div><div className="art-footer">Panel de gestión · Biblioteca</div></div><div className="login-side"><div className="login-card"><div className="login-icon"><BookOpen /></div><span className="eyebrow dark">BIENVENIDO</span><h2>Iniciar sesión</h2><p>Ingresa con la cuenta de tu biblioteca.</p><form onSubmit={submit}><label>Usuario<input autoComplete="username" value={username} onChange={e => setUsername(e.target.value)} required /></label><label>Contraseña<input type="password" autoComplete="current-password" value={password} onChange={e => setPassword(e.target.value)} required /></label>{error && <div className="inline-error" role="alert">{error}</div>}<button className="primary full" disabled={busy}>{busy ? 'Ingresando…' : 'Ingresar'} <span>→</span></button></form><div className="login-foot">Acceso exclusivo para el equipo de biblioteca</div></div></div></div>;
}

function PageHeading({ eyebrow, title, description, action }) { return <div className="page-heading"><div><span className="eyebrow dark">{eyebrow}</span><h1>{title}</h1><p>{description}</p></div>{action}</div>; }
function Panel({ children, className = '' }) { return <section className={`panel ${className}`}>{children}</section>; }
function Empty({ text }) { return <div className="empty"><div className="empty-icon"><BookOpen /></div><p>{text}</p></div>; }
function Pager({ data, page, setPage }) { if (!data || data.total <= data.size) return null; const pages = Math.ceil(data.total / data.size); return <div className="pager"><span>{data.total} registros</span><div><button disabled={page <= 1} onClick={() => setPage(page - 1)}>Anterior</button><span>Página {page} de {pages}</span><button disabled={page >= pages} onClick={() => setPage(page + 1)}>Siguiente</button></div></div>; }
function Cover({ book, api }) { const [src, setSrc] = useState(''); useEffect(() => { let active = true; let objectUrl = ''; if (book.cover_key) api(`/books/${book.id}/cover`).then(blob => { objectUrl = URL.createObjectURL(blob); if (active) setSrc(objectUrl); }).catch(() => {}); return () => { active = false; if (objectUrl) URL.revokeObjectURL(objectUrl); }; }, [book.id, book.cover_key]); return src ? <img alt={`Portada de ${book.title}`} src={src} /> : <div className="cover-placeholder"><BookOpen size={30} /><span>{book.category.name}</span></div>; }

function Books({ api, role, onError, onDone }) {
  const [query, setQuery] = useState(''); const [categoryId, setCategoryId] = useState(''); const [books, setBooks] = useState({ items: [], total: 0, size: 20 }); const [categories, setCategories] = useState([]); const [page, setPage] = useState(1); const [showForm, setShowForm] = useState(false); const [editingId, setEditingId] = useState(''); const [busy, setBusy] = useState(false);
  const [form, setForm] = useState({ title: '', author: '', isbn: '', category_id: '', total_copies: 1 });
  const searchUrl = (q, category, p) => { const params = new URLSearchParams({ page: String(p), size: '20' }); if (q) params.set('q', q); if (category) params.set('category_id', category); return `/books?${params}`; };
  const load = async () => { try { const [list, cats] = await Promise.all([api(searchUrl(query, categoryId, page)), api('/categories')]); setBooks(list); setCategories(cats.items); if (!form.category_id && cats.items[0]) setForm(f => ({ ...f, category_id: cats.items[0].id })); } catch (e) { onError(e.message); } };
  useEffect(() => { load(); }, [page]);
  async function search(e) { e.preventDefault(); setPage(1); try { setBooks(await api(searchUrl(query, categoryId, 1))); } catch (e) { onError(e.message); } }
  async function save(e) { e.preventDefault(); setBusy(true); try { const payload = { title: form.title, author: form.author, category_id: form.category_id, total_copies: Number(form.total_copies) }; if (!editingId) payload.isbn = form.isbn; await api(editingId ? `/books/${editingId}` : '/books', { method: editingId ? 'PUT' : 'POST', body: JSON.stringify(payload) }); setShowForm(false); setEditingId(''); setForm(f => ({ ...f, title: '', author: '', isbn: '', total_copies: 1 })); onDone(editingId ? 'Libro actualizado.' : 'Libro agregado al catálogo.'); await load(); } catch (e) { onError(e.message); } finally { setBusy(false); } }
  function edit(book) { setEditingId(book.id); setForm({ title: book.title, author: book.author, isbn: book.isbn, category_id: book.category.id, total_copies: book.total_copies }); setShowForm(true); }
  async function remove(book) { if (!window.confirm(`¿Dar de baja “${book.title}”?`)) return; try { await api(`/books/${book.id}`, { method: 'DELETE' }); onDone('Libro dado de baja.'); await load(); } catch (e) { onError(e.message); } }
  async function removeCover(book) { try { await api(`/books/${book.id}/cover`, { method: 'DELETE' }); onDone('Portada eliminada.'); await load(); } catch (e) { onError(e.message); } }
  async function upload(book, file) { if (!file) return; const body = new FormData(); body.append('file', file); try { await api(`/books/${book.id}/cover`, { method: 'PUT', body }); onDone('Portada actualizada.'); await load(); } catch (e) { onError(e.message); } }
  return <><PageHeading eyebrow="COLECCIÓN" title="Catálogo de libros" description="Consulta y administra los títulos disponibles." action={role === 'admin' && <button className="primary" onClick={() => { setEditingId(''); setForm({ title: '', author: '', isbn: '', category_id: categories[0]?.id || '', total_copies: 1 }); setShowForm(!showForm); }}><Plus size={17} /> Agregar libro</button>} />
    {showForm && <Panel className="form-panel"><div className="panel-title"><div><h2>{editingId ? 'Editar libro' : 'Nuevo libro'}</h2><p>Completa la información del ejemplar.</p></div></div><form className="form-grid" onSubmit={save}><label>Título<input value={form.title} onChange={e => setForm({ ...form, title: e.target.value })} maxLength="250" required /></label><label>Autor<input value={form.author} onChange={e => setForm({ ...form, author: e.target.value })} maxLength="200" required /></label>{!editingId && <label>ISBN (13 dígitos)<input value={form.isbn} onChange={e => setForm({ ...form, isbn: e.target.value.replace(/\D/g, '').slice(0, 13) })} inputMode="numeric" required /></label>}<label>Categoría<select value={form.category_id} onChange={e => setForm({ ...form, category_id: e.target.value })} required>{categories.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}</select></label><label>Ejemplares<input type="number" min="1" value={form.total_copies} onChange={e => setForm({ ...form, total_copies: e.target.value })} required /></label><div className="form-actions"><button type="button" className="secondary" onClick={() => { setShowForm(false); setEditingId(''); }}>Cancelar</button><button className="primary" disabled={busy}>{busy ? 'Guardando…' : 'Guardar libro'}</button></div></form></Panel>}
    <Panel><form className="toolbar catalog-toolbar" onSubmit={search}><div className="search-box"><Search size={17} /><input placeholder="Buscar por título o autor" value={query} onChange={e => setQuery(e.target.value)} /><button className="search-submit" aria-label="Buscar"><span>Buscar</span></button></div><select className="filter-select" aria-label="Filtrar por categoría" value={categoryId} onChange={e => setCategoryId(e.target.value)}><option value="">Todas las categorías</option>{categories.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}</select><span className="result-count">{books.total ?? books.items.length} títulos</span></form>
      {books.items.length ? <div className="book-grid">{books.items.map(book => <article className="book-card" key={book.id}><div className="book-cover"><Cover book={book} api={api} /><span className="category-pill">{book.category.name}</span></div><div className="book-info"><h3>{book.title}</h3><p>{book.author}</p><div className="book-meta"><span>ISBN {book.isbn}</span><span className={book.available_copies ? 'available' : 'unavailable'}>{book.available_copies} / {book.total_copies} disp.</span></div>{role === 'admin' && <div className="book-actions"><button className="icon-btn" title="Editar libro" onClick={() => edit(book)}><Pencil size={14}/></button><label className="icon-btn cover-upload" title="Subir portada"><ImagePlus size={15}/><input type="file" accept="image/jpeg,image/png" onChange={e => upload(book, e.target.files?.[0])}/></label>{book.cover_key && <button className="icon-btn" title="Quitar portada" onClick={() => removeCover(book)}><X size={14}/></button>}<button className="icon-btn danger-icon" title="Dar de baja" onClick={() => remove(book)}><Trash2 size={14}/></button></div>}</div></article>)}</div> : <Empty text="No hay libros para mostrar. Prueba otra búsqueda o agrega el primer título."/>}
      <Pager data={books} page={page} setPage={setPage} />
    </Panel>
  </>;
}

function Members({ api, onError, onDone }) {
  const [query, setQuery] = useState(''); const [data, setData] = useState({ items: [], total: 0, size: 20 }); const [page, setPage] = useState(1); const [show, setShow] = useState(false); const [form, setForm] = useState({ full_name: '', document_number: '' });
  const load = async (q = query, p = page) => { try { setData(await api(`/members?q=${encodeURIComponent(q)}&page=${p}&size=20`)); } catch (e) { onError(e.message); } };
  useEffect(() => { load(query, page); }, [page]);
  async function save(e) { e.preventDefault(); try { await api('/members', { method: 'POST', body: JSON.stringify(form) }); setShow(false); setForm({ full_name: '', document_number: '' }); onDone('Socio registrado correctamente.'); await load(); } catch (e) { onError(e.message); } }
  return <><PageHeading eyebrow="COMUNIDAD" title="Socios" description="Registra y encuentra a las personas afiliadas a la biblioteca." action={<button className="primary" onClick={() => setShow(!show)}><Plus size={17} /> Nuevo socio</button>} />
    {show && <Panel className="form-panel"><div className="panel-title"><h2>Registrar socio</h2></div><form className="form-grid two" onSubmit={save}><label>Nombre completo<input value={form.full_name} onChange={e => setForm({ ...form, full_name: e.target.value })} required /></label><label>Número de documento<input value={form.document_number} onChange={e => setForm({ ...form, document_number: e.target.value })} required /></label><div className="form-actions"><button type="button" className="secondary" onClick={() => setShow(false)}>Cancelar</button><button className="primary">Guardar socio</button></div></form></Panel>}
    <Panel><form className="toolbar" onSubmit={e => { e.preventDefault(); setPage(1); load(query, 1); }}><div className="search-box"><Search size={17} /><input placeholder="Buscar por nombre o documento" value={query} onChange={e => setQuery(e.target.value)} /><button className="search-submit"><span>Buscar</span></button></div><span className="result-count">{data.total} socios</span></form>
      {data.items.length ? <div className="table-wrap"><table><thead><tr><th>Socio</th><th>Documento</th><th>Estado</th><th>Préstamos activos</th></tr></thead><tbody>{data.items.map(m => <MemberRow key={m.id} member={m} api={api} />)}</tbody></table></div> : <Empty text="No hay socios registrados con esos criterios."/>}<Pager data={data} page={page} setPage={setPage}/>
    </Panel>
  </>;
}
function MemberRow({ member, api }) { const [detail, setDetail] = useState(null); useEffect(() => { api(`/members/${member.id}`).then(setDetail).catch(() => {}); }, [member.id]); return <tr><td><div className="person"><span className="person-avatar">{member.full_name.slice(0,1).toUpperCase()}</span><strong>{member.full_name}</strong></div></td><td>{member.document_number}</td><td><span className="badge green">Activo</span></td><td>{detail?.active_loans ?? '—'}</td></tr>; }

function Loans({ api, onError, onDone }) {
  const [data, setData] = useState({ items: [], total: 0, size: 20 }); const [members, setMembers] = useState([]); const [books, setBooks] = useState([]); const [show, setShow] = useState(false); const [page, setPage] = useState(1); const [memberId, setMemberId] = useState(''); const [bookIds, setBookIds] = useState([]); const [busy, setBusy] = useState(false);
  const load = async () => { try { const result = await api(`/loans?page=${page}&size=20`); setData(result); } catch (e) { onError(e.message); } };
  useEffect(() => { load(); }, [page]);
  async function openForm() { try { const [m, b] = await Promise.all([api('/members?size=50'), api('/books?size=50')]); setMembers(m.items); setBooks(b.items.filter(x => x.available_copies > 0)); setShow(true); } catch (e) { onError(e.message); } }
  async function create(e) { e.preventDefault(); setBusy(true); try { await api('/loans', { method: 'POST', body: JSON.stringify({ member_id: memberId, items: bookIds.map(book_id => ({ book_id })) }) }); setShow(false); setBookIds([]); onDone('Préstamo registrado. La fecha de devolución se calcula a 14 días.'); await load(); } catch (e) { onError(e.message); } finally { setBusy(false); } }
  async function returnBook(loanId, itemId) { try { await api(`/loans/${loanId}/items/${itemId}/return`, { method: 'POST' }); onDone('Devolución registrada y ejemplar disponible.'); await load(); } catch (e) { onError(e.message); } }
  return <><PageHeading eyebrow="CIRCULACIÓN" title="Préstamos" description="Registra nuevas salidas y controla las devoluciones." action={<button className="primary" onClick={openForm}><Plus size={17} /> Nuevo préstamo</button>} />
    {show && <Panel className="form-panel"><div className="panel-title"><div><h2>Registrar préstamo</h2><p>Máximo tres libros. Plazo de devolución: 14 días.</p></div><button className="icon-btn" onClick={() => setShow(false)} aria-label="Cerrar formulario"><X size={18}/></button></div><form className="form-grid two" onSubmit={create}><label>Socio<select value={memberId} onChange={e => setMemberId(e.target.value)} required><option value="">Seleccionar socio</option>{members.map(m => <option key={m.id} value={m.id}>{m.full_name} · {m.document_number}</option>)}</select></label><fieldset className="book-picker"><legend>Libros disponibles (selecciona hasta 3)</legend>{books.length ? books.map(b => <label className="check-row" key={b.id}><input type="checkbox" checked={bookIds.includes(b.id)} disabled={!bookIds.includes(b.id) && bookIds.length >= 3} onChange={e => setBookIds(ids => e.target.checked ? [...ids, b.id] : ids.filter(id => id !== b.id))}/><span><strong>{b.title}</strong><small>{b.author} · {b.available_copies} disponibles</small></span></label>) : <span className="muted">No hay ejemplares disponibles.</span>}</fieldset><div className="form-actions"><button type="button" className="secondary" onClick={() => setShow(false)}>Cancelar</button><button className="primary" disabled={busy || !memberId || !bookIds.length}>{busy ? 'Registrando…' : 'Crear préstamo'}</button></div></form></Panel>}
    <Panel>{data.items.length ? <div className="loan-list">{data.items.map(loan => <article className="loan-card" key={loan.id}><div className="loan-head"><div><span className="loan-id">PRÉSTAMO · {loan.id.slice(0,8).toUpperCase()}</span><h3>{loan.member_name}</h3><small>Registrado el {new Date(loan.loaned_at).toLocaleDateString('es-CO')}</small></div><span className={`badge ${loan.status === 'overdue' ? 'red' : loan.status === 'closed' ? 'gray' : 'green'}`}>{loan.status === 'overdue' ? 'Vencido' : loan.status === 'closed' ? 'Cerrado' : 'Activo'}</span></div><div className="loan-items">{loan.items.map(item => <div className="loan-item" key={item.id}><div className="item-book"><BookOpen size={18}/><div><strong>{item.book_title}</strong><small>Devolución: {new Date(item.due_at).toLocaleDateString('es-CO')}</small></div></div>{item.returned_at ? <span className="badge gray">Devuelto</span> : <button className="secondary small" onClick={() => returnBook(loan.id, item.id)}><RotateCcw size={14}/> Devolver</button>}</div>)}</div></article>)}</div> : <Empty text="Aún no hay préstamos registrados."/>}<Pager data={data} page={page} setPage={setPage}/></Panel>
  </>;
}

function Overdue({ api, onError, onDone }) { const [items, setItems] = useState([]); const load = async () => { try { setItems((await api('/loans/overdue')).items); } catch (e) { onError(e.message); } }; useEffect(() => { load(); }, []); async function returnItem(x) { try { await api(`/loans/${x.loan_id}/items/${x.item_id}/return`, { method: 'POST' }); onDone('Devolución registrada.'); await load(); } catch (e) { onError(e.message); } } return <><PageHeading eyebrow="SEGUIMIENTO" title="Préstamos vencidos" description="Libros que superaron su fecha prevista de devolución." /><Panel>{items.length ? <div className="table-wrap"><table><thead><tr><th>Libro</th><th>Socio</th><th>Fecha de vencimiento</th><th>Atraso</th><th></th></tr></thead><tbody>{items.map(x => <tr key={x.item_id}><td><strong>{x.book_title}</strong></td><td>{x.member_name}</td><td>{new Date(x.due_at).toLocaleDateString('es-CO')}</td><td><span className="badge red">{x.days_late} días</span></td><td><button className="secondary small" onClick={() => returnItem(x)}><RotateCcw size={14}/> Registrar devolución</button></td></tr>)}</tbody></table></div> : <Empty text="No hay préstamos vencidos. La lista se actualizará cuando corresponda."/>}</Panel></>; }

function Report({ api, role, onError }) { const [from, setFrom] = useState(new Date(new Date().getFullYear(), new Date().getMonth(), 1).toISOString().slice(0,10)); const [to, setTo] = useState(new Date().toISOString().slice(0,10)); const [rows, setRows] = useState(null); const [busy, setBusy] = useState(false); async function load(e) { e.preventDefault(); setBusy(true); try { setRows(await api(`/reports/most-borrowed?from=${from}&to=${to}`)); } catch (e) { onError(e.message); } finally { setBusy(false); } } return <><PageHeading eyebrow="ANÁLISIS" title="Libros más prestados" description="Compara la demanda de títulos en un rango de fechas." />{role !== 'admin' ? <Panel><Empty text="Este reporte está disponible para el rol administrador."/></Panel> : <Panel><form className="report-filter" onSubmit={load}><label>Desde<input type="date" value={from} onChange={e => setFrom(e.target.value)} required /></label><label>Hasta<input type="date" value={to} onChange={e => setTo(e.target.value)} required /></label><button className="primary" disabled={busy}>{busy ? 'Consultando…' : 'Generar reporte'}</button></form>{rows && (rows.rows.length ? <div className="table-wrap"><table><thead><tr><th>#</th><th>Título</th><th>Categoría</th><th>Préstamos</th></tr></thead><tbody>{rows.rows.map((x,i) => <tr key={`${x.book_id}-${i}`}><td><span className="rank">{String(i+1).padStart(2,'0')}</span></td><td><strong>{x.book_title}</strong></td><td>{x.category_name}</td><td><span className="count-pill">{x.times_borrowed}</span></td></tr>)}</tbody></table></div> : <Empty text="No hay préstamos en ese rango de fechas."/> )}</Panel>}</>; }

function UsersPanel({ api, onError, onDone }) { const [form, setForm] = useState({ username: '', password: '', role: 'librarian' }); async function save(e) { e.preventDefault(); try { const result = await api('/users', { method: 'POST', body: JSON.stringify(form) }); onDone(`Se creó el usuario ${result.username}.`); setForm({ username: '', password: '', role: 'librarian' }); } catch (e) { onError(e.message); } } return <><PageHeading eyebrow="ADMINISTRACIÓN" title="Usuarios del sistema" description="Crea cuentas con rol bibliotecario para el equipo."/><Panel className="form-panel"><div className="panel-title"><h2>Crear bibliotecario</h2></div><form className="form-grid two" onSubmit={save}><label>Nombre de usuario<input minLength="3" maxLength="120" value={form.username} onChange={e => setForm({ ...form, username: e.target.value })} required /></label><label>Contraseña inicial<input type="password" minLength="8" value={form.password} onChange={e => setForm({ ...form, password: e.target.value })} required /><small className="field-hint">Mínimo 8 caracteres. El sistema guarda únicamente el hash.</small></label><div className="form-actions"><button className="primary">Crear usuario</button></div></form></Panel></>; }
